public class Transaction {
  private long acno;
  private String particulars;
}
