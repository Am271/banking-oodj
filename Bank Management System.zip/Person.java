public class Person {
    protected String name;
    protected String phone_no;
    protected String email;
    protected String address;
}
